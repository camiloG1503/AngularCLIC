import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/userModel.js';

export const register = (req, res) => {
  const { name, email, password } = req.body;

  // Verificar si el usuario ya existe
  User.findByEmail(email, (err, results) => {
    if (err) return res.status(500).json({ message: 'Error en el servidor' });

    if (results.length > 0) {
      return res.status(400).json({ message: 'El usuario ya existe' });
    }

    // Encriptar contraseña
    const hashedPassword = bcrypt.hashSync(password, 8);
    const newUser = { nombre: name, email, password: hashedPassword, rol: "turista" }; // puedes ajustar el rol por defecto

    // Insertar usuario
    User.create(newUser, (err, result) => {
      if (err) return res.status(500).json({ message: 'Error al registrar el usuario' });
      res.status(201).json({ message: 'Usuario registrado exitosamente' });
    });
  });
};

export const login = (req, res) => {
  const { email, password } = req.body;

  // Buscar usuario por email
  User.findByEmail(email, (err, results) => {
    if (err) return res.status(500).json({ message: 'Error en el servidor' });

    if (results.length === 0) {
      return res.status(400).json({ message: 'Usuario no encontrado' });
    }

    const user = results[0];

    // Verificar contraseña
    const passwordIsValid = bcrypt.compareSync(password, user.password);

    if (!passwordIsValid) {
      return res.status(401).json({ message: 'Contraseña incorrecta' });
    }

    // Generar token JWT
    const token = jwt.sign({ id: user.id_usuario, rol: user.rol }, process.env.JWT_SECRET, {
      expiresIn: '24h',
    });

    res.status(200).json({
      message: 'Inicio de sesión exitoso',
      token,
      usuario: {
        id: user.id_usuario,
        nombre: user.nombre,
        email: user.email,
        rol: user.rol
      }
    });
  });
};
''