import db from "../../config/db.js";

class User {
  static getAll() {
    return new Promise((resolve, reject) => {
      db.query("SELECT * FROM usuarios", (err, results) => {
        if (err) return reject(err);
        resolve(results);
      });
    });
  }

  static getById(id) {
    return new Promise((resolve, reject) => {
      db.query("SELECT * FROM usuarios WHERE id_usuario = ?", [id], (err, results) => {
        if (err) return reject(err);
        resolve(results[0]);
      });
    });
  }

  static findByEmail(email, callback) {
    db.query("SELECT * FROM usuarios WHERE email = ?", [email], (err, results) => {
      if (err) return callback(err, null);
      callback(null, results);
    });
  }

  static create(user, callback) {
    db.query("INSERT INTO usuarios SET ?", user, (err, results) => {
      if (err) return callback(err, null);
      callback(null, results);
    });
  }

  static update(id, user) {
    return new Promise((resolve, reject) => {
      db.query("UPDATE usuarios SET ? WHERE id_usuario = ?", [user, id], (err, results) => {
        if (err) return reject(err);
        resolve(results.affectedRows);
      });
    });
  }

  static delete(id) {
    return new Promise((resolve, reject) => {
      db.query("DELETE FROM usuarios WHERE id_usuario = ?", [id], (err, results) => {
        if (err) return reject(err);
        resolve(results.affectedRows);
      });
    });
  }
}

export default User;
