import express from "express";
import { 
  getUsuarios, 
  getUsuarioById,
  createUsuario, 
  updateUsuario, 
  deleteUsuario 
} from "../controllers/usuariosController.js";
import { verificarToken } from "../middlewares/authMiddleware.js";

const router = express.Router();


router.get("/", verificarToken, getUsuarios);
router.get("/:id", getUsuarioById);
router.post("/", createUsuario);
router.put("/:id", updateUsuario);
router.delete("/:id", deleteUsuario);

export default router;
